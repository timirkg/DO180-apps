#!/bin/bash

podman build -t do180/quote-php .
