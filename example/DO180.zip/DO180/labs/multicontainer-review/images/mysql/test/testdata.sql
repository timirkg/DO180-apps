create table contacts (
  name varchar(255),
  email varchar(100)
);

insert into contacts values (
  'John Doe', 'jdoe@nowhere.net'
);

